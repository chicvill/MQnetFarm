from setuptools import setup, find_packages

setup(
    name='sf_smartfarm_v2',
    version='0.3',
    packages=find_packages(),
    description='Smart Farm Node & Device Management System with ESP-NOW and MQTT emulation',
)
